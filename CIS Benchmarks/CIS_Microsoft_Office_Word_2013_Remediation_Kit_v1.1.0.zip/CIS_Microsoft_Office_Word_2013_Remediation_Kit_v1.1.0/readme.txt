﻿To import these settings into Active Directory, perform the following:

1) Unzip the GPO of your choice to a local folder on the computer you plan to import from.
2) Run gpmc.msc on the computer
3) Go to the Group Policy Object and/or create a new Group Policy Object
4) Right click on the selected Group Policy Object and click on "import settings"
5) Click Next
6) Click Next
7) Click Browse and select the folder that is holding the CIS GPO
8) Click Next
9) Click Next
10) Click finish, at this point the GPO should be imported into

To implement these settings on a standalone computer, perform the following:
Download and Install the LGPO program developed by Microsoft. https://blogs.technet.microsoft.com/secguide/2016/01/21/lgpo-exe-local-group-policy-object-utility-v1-0/





